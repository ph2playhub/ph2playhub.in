# PH² PLAY HUB Mobile App — Starter Project

A mobile-first Progressive Web App starter for PH² PLAY HUB.

## Included
- Neon black/violet gaming UI
- Home, shop, service and contact sections
- WhatsApp ordering and service buttons
- PS5 / PS4 / Xbox / PSP category filters
- Installable PWA structure
- Responsive design for mobile and desktop

## Run locally
Open `index.html` in a browser, or use a local server:
`python -m http.server 8000`

Then visit `http://localhost:8000`.

## Publish
This project can be hosted on GitHub Pages. After publishing, visitors can use the browser's "Install app" / "Add to Home Screen" option on supported devices.

## Next production steps
1. Replace emoji product artwork with actual PH² PLAY HUB product images.
2. Connect a real product/order database.
3. Add admin panel for stock and prices.
4. Add Google Maps and Google Business Profile links.
5. Package as Android APK/AAB with Capacitor or a native Android project.

const products=[
 {name:"PlayStation 5",cat:"PS5",icon:"🎮",price:"Enquire"},
 {name:"PlayStation 4",cat:"PS4",icon:"🕹️",price:"Enquire"},
 {name:"Xbox Console",cat:"Xbox",icon:"⚡",price:"Enquire"},
 {name:"PSP Console",cat:"PSP",icon:"🎒",price:"Enquire"}
];
function render(list=products){document.querySelector("#products").innerHTML=list.map(p=>`<article class="product"><div class="product-img">${p.icon}</div><div class="product-body"><small>${p.cat}</small><h4>${p.name}</h4><div class="price">${p.price}</div></div></article>`).join("")}
function filterProducts(cat){render(products.filter(p=>p.cat===cat));document.querySelector("#products").scrollIntoView({behavior:"smooth"})}
function showAll(){render()}
function nav(page,el){document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.remove("active"));el.classList.add("active");if(page==="shop"){showAll();document.querySelector("#products").scrollIntoView({behavior:"smooth"})}else if(page==="service"){document.querySelector(".service-card").scrollIntoView({behavior:"smooth"})}else if(page==="contact"){document.querySelector(".info-card").scrollIntoView({behavior:"smooth"})}else window.scrollTo({top:0,behavior:"smooth"})}
render();
if("serviceWorker" in navigator){navigator.serviceWorker.register("sw.js").catch(()=>{})}